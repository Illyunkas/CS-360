package com.example.eventtrackingapp_project_three_dan_peterson;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * This is my file for local unit tests. These tests will run on my development machine (the host),
 * not on an Android device.
 *
 * Here's the link to the official testing documentation if I ever need it:
 * http://d.android.com/tools/testing
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        // This is just a simple check to make sure my unit test setup is working correctly.
        assertEquals(4, 2 + 2);
    }
}
