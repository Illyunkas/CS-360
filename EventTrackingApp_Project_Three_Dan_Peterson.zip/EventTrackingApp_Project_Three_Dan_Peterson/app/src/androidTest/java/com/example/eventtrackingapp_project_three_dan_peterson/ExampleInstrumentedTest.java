package com.example.eventtrackingapp_project_three_dan_peterson;

import android.content.Context;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

/**
 * This is my instrumented test file, which I'll use to run tests on a real or emulated Android device.
 * I should check out the official testing documentation if I ever need a refresher:
 * http://d.android.com/tools/testing
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    @Test
    public void useAppContext() {
        // I'm getting the context of my app here to make sure everything is set up correctly.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        //noinspection SpellCheckingInspection
        assertEquals("com.example.eventtrackingapp_project_three_dan_peterson", appContext.getPackageName());
    }
}
