package com.example.eventtrackingapp_project_three_dan_peterson;

/**
 * This is my data class for a single event.
 * I'm using it to hold the ID, title, and date for each event I pull from the database.
 * It's a simple POJO (Plain Old Java Object).
 */
public class Event {
    private final int id;
    private final String title;
    private final String date;

    public Event(int id, String title, String date) {
        this.id = id;
        this.title = title;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDate() {
        return date;
    }
}
