package com.example.eventtrackingapp_project_three_dan_peterson;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/**
 * This is the default MainActivity that Android Studio created for me.
 * My app's real starting point is the LoginActivity, so this file isn't really used,
 * but I'll keep it here for now.
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // This line enables edge-to-edge display for my app, allowing it to draw behind the system bars.
        EdgeToEdge.enable(this);

        setContentView(R.layout.activity_main);

        // I'm setting a listener here to handle the window insets (the space taken up by the system bars).
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            // I get the insets for the system bars (status bar, navigation bar).
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            // Then I apply those insets as padding to my main view.
            // This prevents my UI from being hidden behind the system bars.
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
