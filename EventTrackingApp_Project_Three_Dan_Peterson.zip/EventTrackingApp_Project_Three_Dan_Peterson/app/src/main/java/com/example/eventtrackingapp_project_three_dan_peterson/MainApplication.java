package com.example.eventtrackingapp_project_three_dan_peterson;

import android.app.Application;
import com.jakewharton.threetenabp.AndroidThreeTen;

/**
 * This is my custom Application class.
 * I'm using it to run code that needs to be initialized once when the app starts.
 */
public class MainApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // I need to initialize the ThreeTenABP library here. This library backports the modern
        // java.time APIs to older Android versions, which is required by the calendar view library I'm using.
        AndroidThreeTen.init(this);
    }
}
