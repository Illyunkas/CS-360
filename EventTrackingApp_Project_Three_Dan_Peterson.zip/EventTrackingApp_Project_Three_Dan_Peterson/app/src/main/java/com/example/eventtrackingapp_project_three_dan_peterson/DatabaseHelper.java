package com.example.eventtrackingapp_project_three_dan_peterson;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "event_tracker.db";
    // I bumped the version to 2 to make sure onUpgrade gets called after I added the user_id column.
    private static final int DATABASE_VERSION = 2;

    // Here's where I define the schema for my users table.
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "_id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // And here's the schema for my events table.
    public static final String TABLE_EVENTS = "events";
    public static final String COLUMN_EVENT_ID = "_id";
    public static final String COLUMN_EVENT_TITLE = "title";
    public static final String COLUMN_EVENT_DATE = "date";
    // This is the new column I added to link an event to a specific user.
    public static final String COLUMN_EVENT_USER_ID = "user_id";

    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS + "("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_USERNAME + " TEXT NOT NULL UNIQUE,"
            + COLUMN_PASSWORD + " TEXT NOT NULL" + ");";

    // I updated the table creation string to include the new user_id column.
    private static final String CREATE_TABLE_EVENTS = "CREATE TABLE " + TABLE_EVENTS + "("
            + COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_EVENT_TITLE + " TEXT NOT NULL,"
            + COLUMN_EVENT_DATE + " TEXT NOT NULL,"
            + COLUMN_EVENT_USER_ID + " INTEGER NOT NULL" + ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_EVENTS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // This is my simple upgrade strategy. For this project, I'll just drop the old table and start fresh.
            // In a real app, I'd need to write a proper data migration script to preserve user data.
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
            db.execSQL(CREATE_TABLE_EVENTS);
        }
    }

    public long getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_USERNAME + " = ?",
                new String[]{username},
                null, null, null)) {
            if (cursor.moveToFirst()) {
                return cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_USER_ID));
            }
        }
        // If the cursor is empty, the user wasn't found, so I'll return -1.
        return -1;
    }

    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USERNAME + " = ?" + " AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};
        try (Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null)) {
            return cursor.getCount() > 0;
        }
    }

    // Now that I have multi-user support, I need to make sure all my event-related methods use the userId.
    public boolean addEvent(String title, String date, long userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_TITLE, title);
        values.put(COLUMN_EVENT_DATE, date);
        values.put(COLUMN_EVENT_USER_ID, userId);
        long result = db.insert(TABLE_EVENTS, null, values);
        return result != -1;
    }

    public void updateEvent(int id, String newTitle) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_TITLE, newTitle);
        db.update(TABLE_EVENTS, values, COLUMN_EVENT_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public void deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_EVENTS, COLUMN_EVENT_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public Set<String> getAllEventDates(long userId) {
        Set<String> eventDates = new HashSet<>();
        SQLiteDatabase db = this.getReadableDatabase();
        try (Cursor cursor = db.query(true, TABLE_EVENTS, new String[]{COLUMN_EVENT_DATE},
                COLUMN_EVENT_USER_ID + " = ?", new String[]{String.valueOf(userId)}, null, null, null, null)) {
            while (cursor.moveToNext()) {
                eventDates.add(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EVENT_DATE)));
            }
        }
        return eventDates;
    }

    public List<Event> getEventsForDate(String date, long userId) {
        List<Event> events = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_EVENT_DATE + " = ? AND " + COLUMN_EVENT_USER_ID + " = ?";
        String[] selectionArgs = {date, String.valueOf(userId)};
        try (Cursor cursor = db.query(TABLE_EVENTS, null, selection, selectionArgs, null, null, null)) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_EVENT_ID));
                String title = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EVENT_TITLE));
                String eventDate = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EVENT_DATE));
                events.add(new Event(id, title, eventDate));
            }
        }
        return events;
    }
}
