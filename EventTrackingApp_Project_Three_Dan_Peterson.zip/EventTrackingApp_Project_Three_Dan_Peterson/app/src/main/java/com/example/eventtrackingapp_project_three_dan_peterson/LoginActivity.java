package com.example.eventtrackingapp_project_three_dan_peterson;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * This is the first screen my user sees. It handles both logging in for existing users
 * and registering new ones.
 */
public class LoginActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 101;
    // I'll use this key to pass the logged-in user's ID to the EventsActivity.
    public static final String USER_ID_KEY = "USER_ID";

    private EditText usernameEditText;
    private EditText passwordEditText;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new DatabaseHelper(this);

        usernameEditText = findViewById(R.id.edit_text_username);
        passwordEditText = findViewById(R.id.edit_text_password);
        Button loginButton = findViewById(R.id.button_login);
        Button registerButton = findViewById(R.id.button_register);

        loginButton.setOnClickListener(v -> loginUser());
        registerButton.setOnClickListener(v -> registerUser());
    }

    private void loginUser() {
        // I get the username and password from the input fields.
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // First, I check if either field is empty.
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, R.string.toast_missing_credentials, Toast.LENGTH_SHORT).show();
            return;
        }

        // Then, I check the credentials against the database.
        if (databaseHelper.checkUser(username, password)) {
            Toast.makeText(this, R.string.toast_login_successful, Toast.LENGTH_SHORT).show();
            // If login is successful, I need to check for SMS permission before proceeding.
            checkSmsPermissionAndProceed();
        } else {
            Toast.makeText(this, R.string.toast_invalid_credentials, Toast.LENGTH_SHORT).show();
        }
    }

    private void registerUser() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, R.string.toast_missing_credentials, Toast.LENGTH_SHORT).show();
            return;
        }

        // I try to add the new user to the database.
        if (databaseHelper.addUser(username, password)) {
            Toast.makeText(this, R.string.toast_registration_successful, Toast.LENGTH_SHORT).show();
        } else {
            // This usually fails if the username is already taken, because of the UNIQUE constraint I set.
            Toast.makeText(this, R.string.toast_registration_failed, Toast.LENGTH_SHORT).show();
        }
    }

    // I created this method to handle the SMS permission check.
    private void checkSmsPermissionAndProceed() {
        // If I don't have the permission, I need to request it.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        } else {
            // If I already have the permission, I can go straight to the app.
            proceedToApp();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            // After the user responds to the permission dialog, I check the result here.
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, R.string.toast_sms_permission_granted, Toast.LENGTH_SHORT).show();
            } else {
                // I should let the user know that notifications will be disabled.
                Toast.makeText(this, R.string.toast_sms_permission_denied, Toast.LENGTH_LONG).show();
            }
            // Regardless of the outcome, I'll proceed to the app.
            proceedToApp();
        }
    }

    // This method handles the final step: moving to the EventsActivity.
    private void proceedToApp() {
        String username = usernameEditText.getText().toString().trim();
        // I need to get the user's ID to pass to the next activity so it knows whose events to load.
        long userId = databaseHelper.getUserId(username);

        Intent intent = new Intent(LoginActivity.this, EventsActivity.class);
        intent.putExtra(USER_ID_KEY, userId);
        startActivity(intent);
        // I call finish() here to remove the LoginActivity from the back stack.
        // This prevents the user from navigating back to it after logging in.
        finish();
    }
}
