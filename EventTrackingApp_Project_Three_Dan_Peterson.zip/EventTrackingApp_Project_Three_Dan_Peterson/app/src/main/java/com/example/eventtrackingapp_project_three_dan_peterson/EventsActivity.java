package com.example.eventtrackingapp_project_three_dan_peterson;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewDecorator;
import com.prolificinteractive.materialcalendarview.DayViewFacade;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;
import com.prolificinteractive.materialcalendarview.spans.DotSpan;

import org.threeten.bp.LocalDate;
import org.threeten.bp.format.DateTimeFormatter;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * This is my main activity for displaying the calendar and the list of events.
 * It handles all the user interaction after they log in.
 */
public class EventsActivity extends AppCompatActivity implements OnDateSelectedListener, EventAdapter.OnEventListener {

    private MaterialCalendarView calendarView;
    private TextView monthTitleTextView;
    private EventAdapter eventAdapter;
    private DatabaseHelper dbHelper;
    private long currentUserId;

    // For now, I'll use a placeholder number. In a real app, I'd get this from the user's profile.
    private static final String PLACEHOLDER_PHONE_NUMBER = "5555555555";
    private static final int CALENDAR_DOT_RADIUS = 3;
    private final DateTimeFormatter monthYearFormatter = DateTimeFormatter.ofPattern("MMMM yyyy");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        dbHelper = new DatabaseHelper(this);

        // First, I need to get the user's ID from the intent. If it's not here, something is wrong.
        currentUserId = getIntent().getLongExtra(LoginActivity.USER_ID_KEY, -1);
        if (currentUserId == -1) {
            Toast.makeText(this, R.string.toast_error_no_user, Toast.LENGTH_LONG).show();
            finish(); // I'll close the activity if there's no valid user.
            return;
        }

        // I'm finding all my new UI components for the custom header.
        calendarView = findViewById(R.id.calendar_view);
        monthTitleTextView = findViewById(R.id.text_view_month_title);
        ImageButton previousMonthButton = findViewById(R.id.button_previous_month);
        ImageButton nextMonthButton = findViewById(R.id.button_next_month);

        // This is where I programmatically hide the default top bar from the calendar library.
        calendarView.setTopbarVisible(false);

        // Now I'll set up the listeners for my custom month navigation.
        updateMonthTitle(calendarView.getCurrentDate());
        calendarView.setOnMonthChangedListener((widget, date) -> updateMonthTitle(date));
        previousMonthButton.setOnClickListener(v -> calendarView.goToPrevious());
        nextMonthButton.setOnClickListener(v -> calendarView.goToNext());

        // Setting up the RecyclerView and the Floating Action Button.
        RecyclerView eventsRecyclerView = findViewById(R.id.recycler_view_events);
        FloatingActionButton fabAddEvent = findViewById(R.id.fab_add_event);

        calendarView.setOnDateChangedListener(this);

        eventsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        eventAdapter = new EventAdapter(this);
        eventsRecyclerView.setAdapter(eventAdapter);

        fabAddEvent.setOnClickListener(v -> showAddEventDialog());

        // I'll call these methods to initialize the view when the activity starts.
        decorateCalendar();
        calendarView.setSelectedDate(CalendarDay.today());
        loadEventsForDate(CalendarDay.today());
    }

    private void updateMonthTitle(CalendarDay date) {
        LocalDate localDate = LocalDate.of(date.getYear(), date.getMonth() + 1, date.getDay());
        monthTitleTextView.setText(localDate.format(monthYearFormatter));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            logout();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void logout() {
        Intent intent = new Intent(EventsActivity.this, LoginActivity.class);
        // These flags clear the activity stack so the user can't press "back" to get into the app after logging out.
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void showAddEventDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.dialog_title_add);

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setHint(R.string.dialog_hint_title);
        builder.setView(input);

        builder.setPositiveButton(R.string.dialog_save_button, (dialog, which) -> {
            String eventTitle = input.getText().toString();
            CalendarDay selectedDate = calendarView.getSelectedDate();
            if (selectedDate == null) {
                // If no date is selected for some reason, I'll just default to today.
                selectedDate = CalendarDay.today();
            }

            LocalDate date = LocalDate.of(selectedDate.getYear(), selectedDate.getMonth() + 1, selectedDate.getDay());
            String formattedDate = date.format(DateTimeFormatter.ISO_LOCAL_DATE);

            if (dbHelper.addEvent(eventTitle, formattedDate, currentUserId)) {
                // After adding the event, I need to refresh the UI.
                decorateCalendar();
                loadEventsForDate(selectedDate);
                String smsMessage = "New Event Created: " + eventTitle + " on " + formattedDate;
                SmsHelper.sendSms(this, PLACEHOLDER_PHONE_NUMBER, smsMessage);
            }
        });
        builder.setNegativeButton(R.string.dialog_cancel_button, (dialog, which) -> dialog.cancel());

        builder.show();
    }

    private void showEditEventDialog(Event event) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.dialog_title_edit);

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setText(event.getTitle());
        builder.setView(input);

        builder.setPositiveButton(R.string.dialog_save_button, (dialog, which) -> {
            String newTitle = input.getText().toString();
            dbHelper.updateEvent(event.getId(), newTitle);
            // I need to reload the events for the currently selected date to show the change.
            loadEventsForDate(Objects.requireNonNull(calendarView.getSelectedDate()));
        });
        builder.setNegativeButton(R.string.dialog_cancel_button, (dialog, which) -> dialog.cancel());

        builder.show();
    }

    // This method gets all the dates with events and tells the calendar to draw dots on them.
    private void decorateCalendar() {
        calendarView.removeDecorators(); // I clear old decorators first to avoid duplicates.
        Set<String> eventDateStrings = dbHelper.getAllEventDates(currentUserId);
        HashSet<CalendarDay> eventDays = new HashSet<>();
        DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;

        for (String dateString : eventDateStrings) {
            LocalDate date = LocalDate.parse(dateString, formatter);
            eventDays.add(CalendarDay.from(date.getYear(), date.getMonthValue() - 1, date.getDayOfMonth()));
        }

        calendarView.addDecorator(new EventDecorator(Color.RED, eventDays));
    }

    @Override
    public void onDateSelected(@NonNull MaterialCalendarView widget, @NonNull CalendarDay date, boolean selected) {
        // When I select a date on the calendar, I'll load the events for that specific day.
        loadEventsForDate(date);
    }

    private void loadEventsForDate(CalendarDay date) {
        LocalDate selectedDate = LocalDate.of(date.getYear(), date.getMonth() + 1, date.getDay());
        String formattedDate = selectedDate.format(DateTimeFormatter.ISO_LOCAL_DATE);
        List<Event> events = dbHelper.getEventsForDate(formattedDate, currentUserId);
        eventAdapter.updateEvents(events);
    }

    @Override
    public void onEditClick(@NonNull Event event) {
        // This is the callback from my adapter. Time to show the edit dialog.
        showEditEventDialog(event);
    }

    @Override
    public void onDeleteClick(int eventId) {
        // This is also from the adapter. I'll delete the event and refresh the UI.
        dbHelper.deleteEvent(eventId);
        decorateCalendar();
        loadEventsForDate(Objects.requireNonNull(calendarView.getSelectedDate()));
    }

    /**
     * This is my custom decorator class for drawing a red dot on dates that have events.
     */
    private static class EventDecorator implements DayViewDecorator {
        private final int color;
        private final HashSet<CalendarDay> dates;

        public EventDecorator(int color, Collection<CalendarDay> dates) {
            this.color = color;
            this.dates = new HashSet<>(dates);
        }

        @Override
        public boolean shouldDecorate(CalendarDay day) {
            // The calendar library calls this for every single day shown. I'll return true if the day is in my set.
            return dates.contains(day);
        }

        @Override
        public void decorate(DayViewFacade view) {
            // This is where I actually add the dot span to the day's view.
            view.addSpan(new DotSpan(CALENDAR_DOT_RADIUS, color));
        }
    }
}
