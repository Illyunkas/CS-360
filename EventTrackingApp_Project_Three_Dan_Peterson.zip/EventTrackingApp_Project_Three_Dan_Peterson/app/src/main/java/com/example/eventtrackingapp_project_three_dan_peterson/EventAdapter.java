package com.example.eventtrackingapp_project_three_dan_peterson;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * This is my adapter for binding my list of Event objects to the RecyclerView.
 */
public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private final List<Event> eventList = new ArrayList<>();
    private final OnEventListener onEventListener;

    /**
     * I created this interface so my Activity can handle clicks on the edit and delete buttons.
     */
    public interface OnEventListener {
        void onEditClick(@NonNull Event event);
        void onDeleteClick(int eventId);
    }

    /**
     * My adapter's constructor.
     * I need to pass in the listener so I can use it in the ViewHolder.
     * @param onEventListener The listener from my EventsActivity.
     */
    public EventAdapter(@NonNull OnEventListener onEventListener) {
        this.onEventListener = onEventListener;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_event, parent, false);
        return new EventViewHolder(view, onEventListener);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = eventList.get(position);
        holder.bind(event);
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    /**
     * I'm using this method to update the event list. I implemented DiffUtil
     * to make the RecyclerView updates more efficient and to get nice animations.
     * @param newEvents The new list of events I want to display.
     */
    public void updateEvents(List<Event> newEvents) {
        final EventDiffCallback diffCallback = new EventDiffCallback(this.eventList, newEvents);
        final DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        this.eventList.clear();
        if (newEvents != null) {
            this.eventList.addAll(newEvents);
        }
        diffResult.dispatchUpdatesTo(this);
    }

    /**
     * This is my ViewHolder for a single event item in the RecyclerView.
     */
    public static class EventViewHolder extends RecyclerView.ViewHolder {
        final TextView titleTextView;
        final TextView dateTextView;
        final Button editButton;
        final Button deleteButton;

        /**
         * The constructor for my ViewHolder. I find all my views here and set up the click listeners.
         * @param itemView The view for the item, which I know is not null.
         * @param onEventListener The listener for clicks, also not null.
         */
        public EventViewHolder(@NonNull View itemView, @NonNull OnEventListener onEventListener) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.text_view_event_title);
            dateTextView = itemView.findViewById(R.id.text_view_event_date);
            editButton = itemView.findViewById(R.id.button_edit_event);
            deleteButton = itemView.findViewById(R.id.button_delete_event);

            itemView.setOnClickListener(v -> {
                // I don't need any action for a general click on the item right now, so I'll leave this empty.
            });

            editButton.setOnClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    // I can safely cast here because I know this ViewHolder is only used with my EventAdapter.
                    assert getBindingAdapter() != null;
                    onEventListener.onEditClick(((EventAdapter) getBindingAdapter()).eventList.get(position));
                }
            });

            deleteButton.setOnClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    // I know for sure the adapter won't be null here.
                    assert getBindingAdapter() != null;
                    int eventId = ((EventAdapter) getBindingAdapter()).eventList.get(position).getId();
                    onEventListener.onDeleteClick(eventId);
                }
            });
        }

        /**
         * This method binds an Event object to the views in this ViewHolder.
         * @param event The event data I want to show.
         */
        public void bind(@NonNull Event event) {
            titleTextView.setText(event.getTitle());
            dateTextView.setText(event.getDate());
        }
    }

    /**
     * This is my own DiffUtil.Callback. It helps the adapter figure out exactly what changed
     * in the list so it can run efficient and cool-looking animations.
     */
    private static class EventDiffCallback extends DiffUtil.Callback {
        private final List<Event> oldList;
        private final List<Event> newList;

        public EventDiffCallback(List<Event> oldList, List<Event> newList) {
            this.oldList = oldList != null ? oldList : new ArrayList<>();
            this.newList = newList != null ? newList : new ArrayList<>();
        }

        @Override
        public int getOldListSize() {
            return oldList.size();
        }

        @Override
        public int getNewListSize() {
            return newList.size();
        }

        @Override
        public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
            if (oldItemPosition >= oldList.size() || newItemPosition >= newList.size()) {
                return false;
            }
            // I'm assuming the event ID is the unique identifier for an item.
            return oldList.get(oldItemPosition).getId() == newList.get(newItemPosition).getId();
        }

        @Override
        public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
            if (oldItemPosition >= oldList.size() || newItemPosition >= newList.size()) {
                return false;
            }
            Event oldEvent = oldList.get(oldItemPosition);
            Event newEvent = newList.get(newItemPosition);

            // I'll check if the title and date are the same to see if the content has changed.
            return Objects.equals(oldEvent.getTitle(), newEvent.getTitle()) &&
                    Objects.equals(oldEvent.getDate(), newEvent.getDate());
        }
    }
}
