package com.example.eventtrackingapp_project_three_dan_peterson;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

/**
 * This is my helper class for handling all SMS-related logic.
 * I created it to keep this functionality separate from my activities.
 */
public class SmsHelper {

    private static final String TAG = "SmsHelper";

    /**
     * I wrote this method to send an SMS message, but only if my app has the required permission.
     *
     * @param context     The context from which I'm calling this method.
     * @param phoneNumber The phone number I want to send the SMS to.
     * @param message     The body of the SMS message.
     */
    public static void sendSms(Context context, String phoneNumber, String message) {
        // First, I need to make sure I actually have permission to send SMS.
        // I don't want the app to crash if the user denied the permission.
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                // If I have permission, I'll get the SmsManager and send the message.
                SmsManager smsManager = context.getSystemService(SmsManager.class);
                if (smsManager != null) {
                    smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                    Toast.makeText(context, R.string.toast_sms_sent, Toast.LENGTH_SHORT).show();
                } else {
                    // This should be rare, but it's good to handle it.
                    throw new Exception("SmsManager not available");
                }
            } catch (Exception e) {
                // If anything goes wrong during sending, I'll log the error and show a failure toast.
                Log.e(TAG, "SMS failed to send.", e);
                Toast.makeText(context, R.string.toast_sms_failed, Toast.LENGTH_SHORT).show();
            }
        }
    }
}
